"use strict";

elFinder.prototype.commands.insertfiles = function() {
    this.title = 'Insert Image(s)';
    this.alwaysEnabled = true;
    this.updateOnSelect = false;

    this.getstate = function(sel) {
        var sel = this.files(sel),
			cnt = sel.length;

        return cnt && $.map(sel, function(f) { return f.phash && f.read && !f.locked ? f : null }).length == cnt ? 0 : -1;
    }

    this.exec = function(hashes) {
        var fm = this.fm,
			dfrd = $.Deferred()
				.fail(function(error) {
				    fm.error(error);
				});

        $.each(this.files(hashes), function(i, file) {
            var fileName = fm.path(file.hash);
			fileName = fileName.replace(/\\/g,"/");
                insertImage(fileName);   
        });
		if($('#modal-image').length){
			$('#modal-image').modal('hide');
		}
      //return dfrd.isRejected() ? dfrd : dfrd.resolve(fm.clipboard(this.hashes(hashes), true));
    }

}
